package Interface;

public interface GymOpen {
	public void run();
}

package GymMain;

import Gym.Gym;

public class GymMain {
	public static void main(String[] args) {
		Gym g = new Gym();
		g.run();
	}
}

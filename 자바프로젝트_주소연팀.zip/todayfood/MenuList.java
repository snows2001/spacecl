package todayfood;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class MenuList {
   
   private List<Menu> list = new ArrayList<Menu>();
   
   MenuList() {
		list.add(new Menu(1, "김치찌개", 8000));
		list.add(new Menu(1, "삼겹살", 15000));
		list.add(new Menu(1, "비빔밥", 12000));
		list.add(new Menu(2, "파스타", 18000));
		list.add(new Menu(2, "햄버거", 8000));
		list.add(new Menu(2, "피자", 17500));
		list.add(new Menu(3, "짜장면", 7000));
		list.add(new Menu(3, "마라탕", 13000));
		list.add(new Menu(3, "볶음밥", 9000));
		list.add(new Menu(4, "규동", 6000));
		list.add(new Menu(4, "초밥", 30000));
		list.add(new Menu(4, "돈까스", 20000));
   }
   
   public void create(int category, String name, int price) {
	  List<Menu> selectList = list.stream()
			   						.filter(menu -> menu.getName().equals(name)).toList();
	  
	  if (selectList.size() > 0) {
		  System.out.println("🚨 이미 존재하는 메뉴입니다.");
		  return;
	  }
	  
	  Menu newMenu = new Menu(category, name, price);
      list.add(newMenu);
      System.out.println("✔ 추가 완료 [ " + newMenu + " ]");
   }; 
   
   public void read(int category) {
	  if (category == 5) {
		  for (int i = 0; i < list.size(); i++)
			  System.out.println((i + 1) + ": " + list.get(i) + " 🗂 " + list.get(i).getStringCategory());
	  } else {
		  AtomicInteger index = new AtomicInteger();
		  
		  list.stream()
		  .filter(menu -> menu.getCategory() == category)
		  .forEach(menu -> System.out.println((index.getAndIncrement() + 1) + ": " + menu));		  
	  }
   }; 
   
   public void update(int category, int price, int menuNo) {      
      List<Menu> selectList = list.stream()
						          	.filter(menu -> menu.getCategory() == category).toList();
      
      Menu selectMenu = selectList.get(menuNo);
      selectMenu.setPrice(price);
      System.out.println("✔ 수정 완료 [ " + selectMenu + " ]");
   };
   
   public void delete(int category, int menuNo) {
      List<Menu> selectList = list.stream()
    		  						.filter (menu -> menu.getCategory() == category).toList();
      
      list.remove(selectList.get(menuNo));
      System.out.println("✔ 삭제 완료");
   };
   
   public void recommend(int category) {
	   Random random = new Random();
	   
	   System.out.println("오늘 당신의 메뉴는...");
	   if (category == 5)
		   System.out.println(list.get(random.nextInt(list.size())));    
	   else {
		  List<Menu> selectList = list.stream()
				  		              .filter( menu -> menu.getCategory() == category )
				  			          .toList();
		  System.out.println(selectList.get(random.nextInt(selectList.size())));
	  }
   }
   
   public long getCategorySize(int category) {
	   return list.stream()
				   .filter(menu -> menu.getCategory() == category)
				   .count();
   }
}
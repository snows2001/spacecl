package todayfood;

public class Menu {
	private String name;
	private int price;
	private int category;
	
	Menu(int category, String name, int price){
		this.category = category;
		this.name = name;
		this.price = price;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	public int getCategory() {
		return category;
	}
	
	public String getStringCategory() {
		switch (category) {
			case 1 :
				return "한식";
			case 2 :
				return "양식";
			case 3 : 
				return "중식";
			case 4 :
				return "일식";
			default :
				return "카테고리 없음";
		}
	}
	
	public void setCategory(int category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "🍽 " + this.name + " 💸 " + this.price;
	}
}
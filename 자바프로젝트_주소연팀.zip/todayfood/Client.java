package todayfood;

import java.util.Scanner;

public class Client {
	private Scanner scanner = new Scanner(System.in);
	private MemberList memberList = new MemberList();
	private Member loginMember;
	
	Client() {
		System.out.println("""
		 _______  _______  ______   _______  __   __  __   _______    _______  _______  _______  ______  
		|       ||       ||      | |   _   ||  | |  ||  | |       |  |       ||       ||       ||      | 
		|_     _||   _   ||  _    ||  |_|  ||  |_|  ||__| |  _____|  |    ___||   _   ||   _   ||  _    |
		  |   |  |  | |  || | |   ||       ||       |     | |_____   |   |___ |  | |  ||  | |  || | |   |
		  |   |  |  |_|  || |_|   ||       ||_     _|     |_____  |  |    ___||  |_|  ||  |_|  || |_|   |
		  |   |  |       ||       ||   _   |  |   |        _____| |  |   |    |       ||       ||       |
		  |___|  |_______||______| |__| |__|  |___|       |_______|  |___|    |_______||_______||______| 
		  
		  오늘 뭐 먹지? 나만의 메뉴 추천기🍔                                                       By. 소연 상석 하성
		""");
	}
	
	public void connect() {
		while (true) {
			System.out.println("""
					
				╓════════════════════════════════════════════════🍔══════════════════════════════════════════════╖
				
				                                 1. 로그인     2. 회원 가입     3. 종료
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int num = Integer.parseInt(scanner.nextLine());
				if (num == 1) {
					this.loginMember = memberList.login(scanner);
					if (this.loginMember == null)
						continue ;
					else
						this.selectFunc();
				}
				else if (num == 2)
					memberList.regist(scanner);
				else if (num == 3) {
					System.out.println("안녕히 가세요 👋");
					scanner.close();
					return;
				}
				else
					throw new Exception();
			} catch (Exception e) {				
				System.out.println("🚨 1에서 2 중에서 입력해주세요.");
			}
		}	
	}
	
	public void selectFunc() {
		while (true) {
			System.out.println("""
					
				╓════════════════════════════════════════════════🍔══════════════════════════════════════════════╖
				
				              1. 메뉴 보기   2. 메뉴 추가   3. 메뉴 삭제   4. 가격 수정   5. 메뉴 추천   6. 로그아웃
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int num = Integer.parseInt(scanner.nextLine());
				switch (num) {
				case 1 :
					this.read();
					break;
				case 2 :
					this.create();
					break;
				case 3 :
					this.delete();
					break;
				case 4 :
					this.update();
					break;
				case 5 :
					this.recommend();
					break;
				case 6 :
					System.out.println("맛있게 드세요 🤤");
					return;
				default :
					throw new Exception();
				}
			} catch (Exception e) {
				System.out.println("🚨 1에서 6 사이의 숫자를 입력해주세요.");
			}
		}
	}
	
	private void read() {
		while (true) {
			System.out.println("""
					
				╓═══════════════════════════════════════════🍔 메뉴 보기 🍔═════════════════════════════════════════╖
				
				                   1. 한식   2. 양식   3. 중식   4. 일식   5. 전체 목록   6. 뒤로 가기
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int category = Integer.parseInt(scanner.nextLine());
				if (category == 6)
					return;
				if (category < 1 || category > 5)
					throw new Exception();
				else
					loginMember.getMenuList().read(category);
			} catch (Exception e) {
				System.out.println("🚨 1에서 6 사이의 숫자를 입력해주세요.");
			}
		}
	}
	
	private void create() {
		while (true) {
			System.out.println("""
					
				╓═══════════════════════════════════════════🍔 메뉴 추가 🍔═════════════════════════════════════════╖
				
				                           1. 한식   2. 양식   3. 중식   4. 일식   5. 뒤로 가기
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int category = Integer.parseInt(scanner.nextLine());
				if (category == 5)
					return;
				if (category < 1 || category > 4)
					throw new Exception();
				else {
					System.out.print("메뉴 이름 입력 : ");
					String name = scanner.nextLine();
					while (true) {
						System.out.print("메뉴 가격 입력 : ");
						try {
							int price = Integer.parseInt(scanner.nextLine());
							if (price < 0)
								throw new Exception();
							loginMember.getMenuList().create(category, name, price);
							break;
						} catch (Exception e) {
							System.out.println("🚨 올바른 값을 입력해주세요.");
						}
					}
				}
			} catch (Exception e) {
				System.out.println("🚨 1에서 5 사이의 숫자를 입력해주세요.");
			}
		}
	}
	
	private void delete() {
		while (true) {
			System.out.println("""
					
				╓═══════════════════════════════════════════🍔 메뉴 삭제 🍔═════════════════════════════════════════╖
				
				                           1. 한식   2. 양식   3. 중식   4. 일식   5. 뒤로 가기
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int category = Integer.parseInt(scanner.nextLine());
				if (category == 5)
					return;
				if (category < 1 || category > 4)
					throw new Exception();
				else {
					System.out.println("✔ 삭제할 메뉴의 번호를 입력해주세요.");
					while (true) {
						loginMember.getMenuList().read(category);
						try {
							int num = Integer.parseInt(scanner.nextLine());
							loginMember.getMenuList().delete(category, num - 1);
							break;
						} catch (Exception e) {
							System.out.println("🚨 올바른 값을 입력해주세요.");
						}
					}
				}
			} catch (Exception e) {
				System.out.println("🚨 1에서 5 사이의 숫자를 입력해주세요.");
			}
		}
	}
	
	private void update() {
		while (true) {
			System.out.println("""
					
				╓═══════════════════════════════════════════🍔 가격 수정 🍔═════════════════════════════════════════╖
				
				                           1. 한식   2. 양식   3. 중식   4. 일식   5. 뒤로 가기
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int category = Integer.parseInt(scanner.nextLine());
				if (category == 5)
					return;
				if (category < 1 || category > 4)
					throw new Exception();
				else {
					System.out.println("✔ 수정할 메뉴의 번호를 입력해주세요.");
					while (true) {
						loginMember.getMenuList().read(category);
						try {
							int num = Integer.parseInt(scanner.nextLine());
							if (loginMember.getMenuList().getCategorySize(category) < num || num <= 0)
								throw new Exception();
							while (true) {
								System.out.print("수정할 가격 입력 : ");
								try {
									int price = Integer.parseInt(scanner.nextLine());
									if (price < 0)
										throw new Exception();
									loginMember.getMenuList().update(category, price, num - 1);
									break;
								} catch (Exception e) {
									System.out.println("🚨 올바른 값을 입력해주세요.");
								}
							}
							break;
						} catch (Exception e) {
							System.out.println("🚨 올바른 값을 입력해주세요.");
						}
					}
				}
			} catch (Exception e) {
				System.out.println("🚨 1에서 5 사이의 숫자를 입력해주세요.");
			}
		}
	}
	
	private void recommend() {
		while (true) {
			System.out.println("""
					
				╓═══════════════════════════════════════════🍔 메뉴 추천 🍔═════════════════════════════════════════╖
				
				                        1. 한식   2. 양식   3. 중식   4. 일식   5. 전체   6. 뒤로 가기
				
				╙════════════════════════════════════════════════🍟══════════════════════════════════════════════╜
				""");
			
			try {
				int category = Integer.parseInt(scanner.nextLine());
				if (category == 6)
					return;
				if (category < 1 || category > 5)
					throw new Exception();
				else
					loginMember.getMenuList().recommend(category);
			} catch (Exception e) {
				System.out.println("🚨 1에서 6 사이의 숫자를 입력해주세요.");
			}
		}
	}
}

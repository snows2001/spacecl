package todayfood;

public class Member {
	private String id;
	private String pw;
	private MenuList menuList;
	
	Member(String id, String pw) {
		this.id = id;
		this.pw = pw;
		this.menuList = new MenuList();
	}

	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPw() {
		return pw;
	}
	
	public void setPw(String pw) {
		this.pw = pw;
	}

	public MenuList getMenuList() {
		return menuList;
	}

	public void setMenuList(MenuList menuList) {
		this.menuList = menuList;
	}
}

package younghun.calculate;
import younghun.menu.*;

import java.util.List;

public class Calculate {
    private static int total;
    // List<Item> itemList = new ArrayList<>();

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public static void printList(List<Item> items){
        System.out.println("You have chosen: ");
        for(Item item: items){
            System.out.println(item);
        }
    }


    public static int calculateTotal(List<Item> items){
        for(Item item : items){
            total = total + item.getNumItem()*item.getPrice();
        }
        return total;
    }


}

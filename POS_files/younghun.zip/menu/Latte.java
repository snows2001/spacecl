package younghun.menu;

import younghun.pos.PrintMenu;

import java.util.List;
import java.util.Scanner;

public class Latte extends Coffee {
    private String milk;

    public Latte(){
        super();
        Scanner sc = new Scanner(System.in);
        PrintMenu.printMilk();
        this.milk = sc.nextLine();
        setPrice(4500);
        setPrice(calculateSelectedPrice());
    }
    public String getMilk() {
        return milk;
    }

    @Override
    int calculateSelectedPrice() {
        switch(getSize()){
            case "Small":
                setPrice(4500);
                break;
            case "Medium":
                setPrice(getPrice()+500);
                break;
            case "Large":
                setPrice(getPrice()+1000);
                break;
        }
        return getPrice();
    }

    @Override
    public String toString() {
        return "Latte{" +
                "numItem=" + getNumItem() +
                ", size='" + getSize() + '\'' +
                ", milk='" + getMilk() + '\'' +
                ", price=" + getPrice() +
                '}';
    }
    }

    //    public static List<Item> latteSelection(List<Item> itemList){
//        System.out.println("몇 개 사시겠습니까?");
//        int numberItem = Scanner(System.in).nextInt();
//        sc.nextLine();
//        System.out.println("원두 종류를 입력해주세요");
//        String coffeeBean = sc.nextLine();
//        System.out.println("사이즈를 입력해주세요");
//        String size = sc.nextLine();
//        System.out.println("우유 종류를 입력해주세요");
//        String milk = sc.nextLine();
//        Item item = new Latte(numberItem,coffeeBean,size,milk);
//        itemList.add(item);
//        return itemList;
//    }


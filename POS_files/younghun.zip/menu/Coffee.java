package younghun.menu;

import younghun.pos.PrintMenu;

import java.util.Scanner;

public class Coffee extends Item {
    private String coffeeBean;

    public Coffee(){
        super();
        Scanner sc = new Scanner(System.in);
        PrintMenu.printCoffeeBean();
        this.coffeeBean = sc.nextLine();


    }
    public String getCoffeeBean() {
        return coffeeBean;
    }

    @Override
    int calculateSelectedPrice(){
        return getPrice();
    }
}

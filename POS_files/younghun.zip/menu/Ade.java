package younghun.menu;

public class Ade extends Beverage{
    public Ade(){
        super();
        setPrice(6000);
    }

    @Override
    public String toString() {
        return "Ade{}";
    }
}

package younghun.menu;

public class Tea extends Beverage{
    public Tea(){
        super();
        setPrice(5000);
    }
}

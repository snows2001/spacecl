package younghun.menu;

public class Americano extends Coffee{
    public Americano(){
        super();
        setPrice(3000);
        setPrice(calculateSelectedPrice());
    }

    @Override
    public String toString() {
        return "Americano{" +
                "numItem=" + getNumItem() +
                ", size='" + getSize() + '\'' +
                ", price=" + getPrice() +
                '}';
    }

    @Override
    int calculateSelectedPrice() {
        switch(getSize()){
            case "Small":
                setPrice(3000);
                break;
            case "Medium":
                setPrice(getPrice()+500);
                break;
            case "Large":
                setPrice(getPrice()+1000);
                break;
        }
        return getPrice();
    }
}

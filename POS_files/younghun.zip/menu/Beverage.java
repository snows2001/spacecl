package younghun.menu;

public class Beverage extends Item{
    public Beverage(){
        super();
    }


    @Override
    int calculateSelectedPrice() {
        return getPrice();
    }
}

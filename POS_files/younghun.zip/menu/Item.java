package younghun.menu;

import younghun.pos.PrintMenu;

import java.util.List;
import java.util.Scanner;

public abstract class Item {
    private int numItem;
    private String size;
    private int price;

    public Item(){
        Scanner sc = new Scanner(System.in);
        PrintMenu.printSize();
        this.size = sc.nextLine();
        System.out.println("How many do you need?");
        this.numItem = sc.nextInt();
        sc.nextLine();
    }

    public Item(int price){
        this.price = price;
    }
    public Item(int numItem, String size) {
        this.numItem = numItem;
        this.size = size;
    }
    public Item(int numItem, String size, int price) {
        this.numItem = numItem;
        this.size = size;
        this.price = price;
    }

    public int getNumItem() {
        return numItem;
    }


    public String getSize() {
        return size;
    }


    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    abstract int calculateSelectedPrice();

    @Override
    public String toString() {
        return "Item{" +
                "numItem=" + numItem +
                ", size='" + size + '\'' +
                ", price=" + price +
                '}';
    }
}

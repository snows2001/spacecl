//package younghun.input;
//
//import younghun.calculate.Calculate;
//import younghun.menu.Item;
//import younghun.menu.Latte;
//
//import java.util.List;
//import java.util.Scanner;
//
///* 이 메소드를 각각의 메뉴의 클라스에 Selection 으로 구현.*/
//
//public class InputCoffee extends Input{
//    public static List<Item> selectionCoffee(String menuSelection, List<Item> itemList){
//        Scanner sc = new Scanner(System.in);
//        switch (menuSelection){
//            case "Latte":
//                System.out.println("몇 개 사시겠습니까?");
//                int numberItem = sc.nextInt();
//                sc.nextLine();
//                System.out.println("원두 종류를 입력해주세요");
//                String coffeeBean = sc.nextLine();
//                System.out.println("사이즈를 입력해주세요");
//                String size = sc.nextLine();
//                System.out.println("우유 종류를 입력해주세요");
//                String milk = sc.nextLine();
//                Item item = new Latte(numberItem,coffeeBean,size,milk);
//                itemList.add(item);
//            case "Americano":
//
//
//        }
//
//        return itemList;
//    }
//
//}

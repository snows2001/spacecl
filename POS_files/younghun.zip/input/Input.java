package younghun.input;

import java.util.Scanner;
import younghun.menu.*;
import java.util.List;
import younghun.calculate.*;

public class Input {

    //public static
}

package younghun.pos;

public class PrintMenu {


    public static void print(){
        System.out.println("Welcome to POS Cafe.");

    }
    public static void printMenu(){
        System.out.println("Please select menu");
        System.out.println("Coffee ===========");
        System.out.println("Americano || Latte");
    }
    public static void printSize(){
        System.out.println("Which size do you want");
        System.out.println("Small || Medium || Large");
    }
    public static void printCoffeeBean(){
        System.out.println("Which CoffeeBean do you want");
        System.out.println("Black || Aroma || Decaf");
    }

    public static void printMilk(){
        System.out.println("Which milk do you want");
        System.out.println("Whole || Low || Soy");
    }

    public static void printEnd(){
        System.out.println("Order more? Type 1 for Yes");
    }

}

package younghun.pos;
import younghun.menu.*;
import younghun.calculate.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class POS {



    public static void start(){
        int i = 1;
        Scanner sc = new Scanner(System.in);
        Calculate calculate= new Calculate();
        List<Item> itemList = new ArrayList<>();
        PrintMenu.print();

        while(i == 1) {
            PrintMenu.printMenu();
            String menuSelection = sc.nextLine();
            String packageName = "younghun.menu";
            try{
                String className = packageName + "." + menuSelection;
                Class<?> clazz = Class.forName(className);

                if (Item.class.isAssignableFrom(clazz)){
                    Constructor<?> constructor = clazz.getConstructor();
                    Item item = (Item) constructor.newInstance();
                    System.out.println("Menu has been selected: " + item.getClass().getSimpleName());
                    itemList.add(item);
                } else{
                    System.out.println("There isn't such menu");
                }
            } catch (ClassNotFoundException e){
                System.out.println("There isn't such menu");
            } catch (NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
                System.out.println("Failed to create an instance of the item: " + e.getMessage());
            }
            Calculate.printList(itemList);
            PrintMenu.printEnd();
            i = sc.nextInt();
            sc.nextLine();
        }

        Calculate.calculateTotal(itemList);
        System.out.println("Total price is: "+ calculate.getTotal());
        sc.close();

    }
}

package younghun;

import younghun.pos.*;

public class Main {
    public static void main(String[] args) {
        //POS POS = new POS();
        POS.start();
    }
}

package ch19.posBackup2;

public class KioskMain {
	public static void main(String[] args) {
		Order order = new Order();
		order.execute();
	}
}

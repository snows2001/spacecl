package ch19.posBackup2;

import java.util.List;

public interface ICancel {
	public int cancelRegister(List<MenuItem> mi); // 특정 메뉴의 주문을 취소
}

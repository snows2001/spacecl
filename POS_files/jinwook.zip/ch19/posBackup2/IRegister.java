package ch19.posBackup2;

import java.util.List;

public interface IRegister {
	public List<MenuItem> register(List<MenuItem> registeredList);
}

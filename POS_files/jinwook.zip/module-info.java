/**
 * 
 */
/**
 * 
 */
module com.lecture.practice {
	requires org.json;
}
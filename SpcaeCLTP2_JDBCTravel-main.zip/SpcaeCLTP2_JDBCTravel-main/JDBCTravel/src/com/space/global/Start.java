package com.space.global;

public interface Start {
	void start();
}

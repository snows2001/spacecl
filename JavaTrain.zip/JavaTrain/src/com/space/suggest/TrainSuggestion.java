package com.space.suggest;

import com.space.user.TrainUser;

public class TrainSuggestion {
	
	private int suggestNum;
	private TrainUser trainUser;
	private String suggestions;
	
	public TrainSuggestion() {}

	public TrainSuggestion(int suggestNum, TrainUser trainUser, String suggestions) {
		super();
		this.suggestNum = suggestNum;
		this.trainUser = trainUser;
		this.suggestions = suggestions;
	}

	public int getSuggestNum() {
		return suggestNum;
	}

	public void setSuggestNum(int suggestNum) {
		this.suggestNum = suggestNum;
	}

	public TrainUser getTrainUser() {
		return trainUser;
	}

	public void setTrainUser(TrainUser trainUser) {
		this.trainUser = trainUser;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}

	@Override
	public String toString() {
		return "#건의사항 번호: " + suggestNum + " ==========" 
				+ "\n#작성자명: " + trainUser.getUserName() 
				+ "\n#건의사항 : " + suggestions + "\n"; 
	}
}

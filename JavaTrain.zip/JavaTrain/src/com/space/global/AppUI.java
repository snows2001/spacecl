package com.space.global;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * Author: 최용준
 * ClassName : AppUI
 * Funcs : Application UIs
 * Date: 2024-07-30
 * */
public class AppUI {
	
	private static Scanner sc = new Scanner(System.in);

	//Messages
	public static void DefaultMessages() {
		System.out.println("# 메뉴를 다시 입력해주세요.");
	}
	
	public static void TerminateProgramMessages() {
		System.out.println("### 99999. 예매 프로그램 종료하기 ");
	}
	
	public static void PressEnter() {
		System.out.println("\n======계속 진행하시려면 ENTER를 누르세요======");
	}	
		
	//Usual Functions
	public static void Shutdown() {
		System.out.println("프로그램을 종료합니다.");
		sc.close();
		System.exit(0);
	}
	
	public static String InputString() { //문자를 입력받는 곳에서 사용
		return sc.nextLine();
	}

	public static int InputInteger() { //숫자를 입력받는 곳에서 사용
		int inputNum = 0;
		try {
			inputNum = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("정수로 입력해 주세요.");
		} finally {
			sc.nextLine();
		}

		return inputNum;
	}
	
	//출발시간~도착시간 = 운행시간을 알려주는 함수  
	public static String BlockTime(LocalDateTime depart,LocalDateTime arrive) {	
		Duration duration = Duration.between(depart, arrive);
		
		// 차이를 시간, 분, 초로 출력
        long hours = duration.toHours();
        long minutes = duration.toMinutes() % 60;
		
        return "[예상운행시간: " + hours + "시간 " + minutes + "분]";
	}


	// 0. 시작화면 출력(Main)
	public static void startScreen() {
		System.out.println("\n========== 열차 예매 관리 시스템 ==========");
		System.out.println("### 1. 현재열차정보 ");
		System.out.println("### 2. 예매되어있는 좌석정보확인");
		System.out.println("### 3. 예매한 좌석 확인 및 좌석 예매");		
		System.out.println("### 4. 예매된 좌석취소 ");		
		System.out.println("### 7. 예매 프로그램 건의사항 작성");		 
		TerminateProgramMessages();
		System.out.println("--------------------------------------");
		System.out.print(">>>");
	}
	
	// 1. 현재운행정보 화면 출력
	public static void TrainSituationScreen() {
		System.out.println("\n========== 현재열차운행정보 ==========");
		System.out.println("### 1000. 모든 열차의 정보");
		System.out.println("### 2. 새마을호"); 
		System.out.println("### 4. 무궁화호");	  
		System.out.println("### 6. ITX"); 
		System.out.println("### 8. KTX");
		System.out.println("### 9. 메인 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("--------------------------------------");
		System.out.print(">>>"); 
	}
	
	// 2. 현재좌석예약정보 화면 출력
	public static void TrainSeatsSituationScreen() {
		System.out.println("\n========== 예매된 좌석정보 ==========");
		System.out.println("### 1000. 모든 열차의 예매정보");
		System.out.println("### 2. 새마을호"); 
		System.out.println("### 4. 무궁화호");
		System.out.println("### 6. ITX"); 
		System.out.println("### 8. KTX");
		System.out.println("### 9. 메인 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("--------------------------------------");
		System.out.print(">>>"); 
	}
	
	// 3. 좌석확인&좌석예매하기 
	public static void TrainSeatsChkNRsvScreen() {
		System.out.println("\n========= 좌석확인&예매하기 =========");
		System.out.println("### 1. 좌석 확인하기");
		System.out.println("### 2. 좌석 예매하기"); 
		System.out.println("### 9. 메인 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}
	
	// 3-1. 예매한 좌석 확인하기 
	public static void SeatsCheckScreen() {
		System.out.println("\n========= 좌석 확인하기 =========");
		System.out.println("### 1. ID로 예매좌석로 확인하기");
		System.out.println("### 2. 이름으로 예매좌석 확인하기");
		System.out.println("### 9. 좌석확인&예매하기 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}

	// 3-2. 좌석 예매하기 
	public static void SeatsReservationScreen() {
		System.out.println("\n========= 좌석 예매하기 =========");
		System.out.println("### 1. 열차좌석 예약하기");
		System.out.println("### 9. 좌석확인&예매하기 페이지로 돌아가기");
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}
			
	// 4. 좌석 취소하기
	public static void SeatsCancelationScreen() {
		System.out.println("### 1. 예매 취소하기");
		System.out.println("### 9. 메인 페이지로 돌아가기");
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}
		
	// 7. 건의사항
	public static void SuggestionScreen() {
		System.out.println("\n========= 예매 프로그램 건의사항 조회&작성 =========");
		System.out.println("### 1. 건의사항 조회하기");
		System.out.println("### 2. 건의사항 작성하기");
		System.out.println("### 9. 메인 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}
	
	// 7-1.건의사항 조회
	public static void SearchingSuggestionScreen() {
		System.out.println("\n========= 건의사항 조회하기 =========");
		System.out.println("### 1. 전체 조회하기");
		System.out.println("### 2. ID로 조회하기");
		System.out.println("### 3. 건의게시판 번호로 조회하기");
		System.out.println("### 9. 건의사항 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}
	
	// 240805. 관리자모드
	public static void ManagementScreen() {
		System.out.println("\n========= 예매 프로그램 관리자 모드 =========");
		System.out.println("### 1. 열차정보 추가하기");
		System.out.println("### 2. 열차정보 수정하기");
		System.out.println("### 3. 열차정보 삭제하기");
		System.out.println("### 9. 메인 페이지로 돌아가기");
		TerminateProgramMessages();
		System.out.println("----------------------------------------");
		System.out.print(">>> "); 
	}


}

package com.space.global;

/*
 * Author: 최용준
 * ClassName : Start
 * Funcs : Implements for Class
 * Date: 2024-08-01
 * */
public interface Start {
	void start();
}

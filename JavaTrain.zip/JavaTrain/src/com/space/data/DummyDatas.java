package com.space.data;

import java.time.LocalDateTime;
import java.util.ArrayList;

import com.space.suggest.TrainSuggestion;
import com.space.train.*;
import com.space.user.TrainUser;

/*
 * Author: 최용준
 * ClassName : DummyDatas
 * Funcs : Dummy Datas
 * Date: 2024-07-30
 * */
public class DummyDatas {
	
	public static ArrayList<TrainUser> tUsers = new ArrayList<TrainUser>();            //사람 정보	
	public static ArrayList<Train> trains = new ArrayList<Train>(); 	               //열차 정보		
	public static ArrayList<TrainSeats> seats = new ArrayList<TrainSeats>();           //좌석예약정보
	public static ArrayList<TrainSuggestion> tUSs = new ArrayList<TrainSuggestion>();  //게시판 정보

	public static void InitializeData() {
		//사람 정보
		tUsers.add(new TrainUser(1, "김미영", 70000));    // 2001, 4번자리
		tUsers.add(new TrainUser(2, "박승기", 120000));   // 4001, 6번자리	
		tUsers.add(new TrainUser(3, "김상석", 110000));   // 6001, 3번자리
		tUsers.add(new TrainUser(4, "이정수", 230000));   // 8001, 5번자리
		tUsers.add(new TrainUser(5, "최진성", 80000));    // 2001, 2번자리
		tUsers.add(new TrainUser(6, "강주임", 70000));    // 6001, 7번자리	
		tUsers.add(new TrainUser(7, "고수빈", 100000));   // 0, 0
		tUsers.add(new TrainUser(8, "이찬성", 40000));    // 0, 0
		tUsers.add(new TrainUser(9, "박재범", 170000));   // 0, 0
		tUsers.add(new TrainUser(10, "정호민", 30000));   // 0, 0
		
		//열차 정보	
		trains.add(new Train(2,"새마을호","서울",LocalDateTime.of(2024, 8, 10, 14, 00)
				,"대전",LocalDateTime.of(2024, 8, 10, 17, 00))); //3시간
		
		trains.add(new Train(4,"무궁화호","서울",LocalDateTime.of(2024, 8, 16, 12, 20)
				,"부산",LocalDateTime.of(2024, 8, 16, 19, 35))); //7시간 15분
		
		trains.add(new Train(6,"ITX","춘천",LocalDateTime.of(2024, 8, 12, 7, 50)
				,"강릉",LocalDateTime.of(2024, 8, 12, 15, 05))); //7시간
		
		trains.add(new Train(8,"KTX","서울",LocalDateTime.of(2024, 8, 17, 17, 10)
				,"부산",LocalDateTime.of(2024, 8, 17, 19, 40))); //2시간 30분
		
		//좌석예약정보
		seats.add(new TrainSeats(tUsers.get(0),trains.get(0),4)); // 김미영, 2001, 4번자리
		seats.add(new TrainSeats(tUsers.get(2),trains.get(2),3)); // 김상석, 6001, 3번자리
		seats.add(new TrainSeats(tUsers.get(4),trains.get(0),2)); // 최진성, 2001, 2번자리
		seats.add(new TrainSeats(tUsers.get(3),trains.get(3),5)); // 이정수, 8001, 5번자리	
		seats.add(new TrainSeats(tUsers.get(1),trains.get(1),6)); // 박승기, 4001, 6번자리	
		seats.add(new TrainSeats(tUsers.get(5),trains.get(2),7)); // 강주임, 6001, 7번자리	
		
		//게시판 정보
		tUSs.add(new TrainSuggestion(1, tUsers.get(0), "여기가 게시판인가요?"));
		tUSs.add(new TrainSuggestion(2, tUsers.get(3), "빨리 여행가고 싶다."));
		tUSs.add(new TrainSuggestion(3, tUsers.get(7), "이거 왜 결제가 안됩니까?"));
		tUSs.add(new TrainSuggestion(4, tUsers.get(4), "윗 댓분 돈 충전 안하신거 아니에요?"));
		tUSs.add(new TrainSuggestion(5, tUsers.get(6), "문의도 여기에 하는게 맞나요?"));
		tUSs.add(new TrainSuggestion(6, tUsers.get(3), "8월 17일 까지 어떻게 기다리죠?"));
		tUSs.add(new TrainSuggestion(7, tUsers.get(9), "윗 댓 초딩입니까? 여기 그런글 적지 말아주세요."));
	}
	
	
}

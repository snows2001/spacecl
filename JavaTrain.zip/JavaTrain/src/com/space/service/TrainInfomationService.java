package com.space.service;

import com.space.data.DummyDatas;
import com.space.global.*;

/*
 * Author: 최민서
 * ClassName : TrainInfomationService
 * Funcs : ShowAllTrians + SelectTrain
 * Date: 2024-08-08
 * */
public class TrainInfomationService implements Start{

	@Override
	public void start() {	
		while(true){
			AppUI.TrainSituationScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case GlobalVariables.returnNum:     //상위 메뉴로 돌아가기
					return; //메인화면으로 돌아가기			
				case GlobalVariables.searchAll:     //전체검색
					ShowAlltrains();
					break;
				case GlobalVariables.saemaeulCode:  //새마을호
				case GlobalVariables.mugunghwaCode: //무궁화호
				case GlobalVariables.itxCode:       //ITX
				case GlobalVariables.ktxCode:       //KTX
					SelectTrain(selection);
					break;
				case GlobalVariables.terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}				
	}

	private void ShowAlltrains() {
		// 모든 열차의 정보를 출력해주세요.
		// 열차는 Arraylist에 저장되어있습니다.
		// 매개변수 받을 필요 있을까?
		System.out.println("모든 열차의 정보조회 결과는 다음과 같습니다.\n");
		for (int i = 0; i < DummyDatas.trains.size(); i++) {
			System.out.println(DummyDatas.trains.get(i).toString());// 열차의 모든 정보 출력
		}	
	}
	
	private void SelectTrain(int selection) {
		// 입력받은 번호에 해당하는 종류의 열차를 출력해주세요
		// ex 2001번 입력 받음 -> 새마을호 열차만 모두 출력
		// 특정 열차를 반환하는 메서드
		switch(selection) {
			case GlobalVariables.saemaeulCode:  //새마을호
				System.out.println("새마을호의 열차정보조회 결과는 다음과 같습니다.");
				break;	
				
			case GlobalVariables.mugunghwaCode: //무궁화호			
				System.out.println("무궁화호의 열차정보조회 결과는 다음과 같습니다.");
				break;	
				
			case GlobalVariables.itxCode:       //ITX
				System.out.println("ITX의 열차정보조회 결과는 다음과 같습니다.");
				break;	
				
			case GlobalVariables.ktxCode:       //KTX
				System.out.println("KTX의 열차정보조회 결과는 다음과 같습니다.");
				break;		
		}
		
		for (int i = 0; i < DummyDatas.trains.size(); i++) {
	        if (DummyDatas.trains.get(i).getTrainNo() == selection) {
	            System.out.println(DummyDatas.trains.get(i).toString());
	        }
	    }
	}
}

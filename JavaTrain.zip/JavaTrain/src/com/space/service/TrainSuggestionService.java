package com.space.service;

import com.space.data.DummyDatas;
import com.space.global.*;
import com.space.suggest.TrainSuggestion;

/*
 * Author: 박재연
 * ClassName : TrainSuggestionService
 * Funcs : Variables of Suggestion
 * Date: 2024-08-08
 * */
public class TrainSuggestionService implements Start, GlobalVariables{

	@Override
	public void start() {
		while(true){		
			AppUI.SuggestionScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case 1: //1. 건의사항 조회하기
					SearchingSuggestion();
					break;
				case 2: //2. 건의사항 작성하기
					WritingSuggestion();
					break;
				case returnNum:
					return; //메인화면으로 돌아가기	
				case terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;	
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}			
	}

	private void SearchingSuggestion() {
		while(true){	
			AppUI.SearchingSuggestionScreen();
			int selection = AppUI.InputInteger();			
			switch(selection) {
				case 1: //1. 건의사항 전체 조회하기
					SearchAllSugesstion();
					break;
				case 2: //2. 건의사항 ID로 조회하기
					SearchByIDNum();
					break;
				case 3: //3. 건의사항게시판 번호로 조회하기
					SearchBySBoardNum();
					break;
				case GlobalVariables.returnNum: 
					return; //건의사항 페이지으로 돌아가기				
				default:
					AppUI.DefaultMessages();	
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}		
	}
	
   private void SearchAllSugesstion() {
	   System.out.println("게시판의 모든 게시글 조회합니다.");
	   for (int g = 0; g < DummyDatas.tUSs.size(); g++) {
		   System.out.println(DummyDatas.tUSs.get(g));
	   }
   }
   
   private void SearchByIDNum() { //회원 한명이 두개의 글을 남겼을 때 게시글 2개 나오게 하는 함수?
       System.out.println("조회하실 ID를 적어주세요.");
       System.out.print(">>>");
	   int inputNumber = AppUI.InputInteger();
      
	   boolean flag = true;
       for (int g = 0; g < DummyDatas.tUSs.size(); g++) {
           if(DummyDatas.tUSs.get(g).getTrainUser().getUserNum() == inputNumber) {
        	   System.out.println(DummyDatas.tUSs.get(g));   
        	   flag = false;
           }   
       }   
       
       if(flag) {
    	   System.out.println("적어주신 ID로 조회되는 게시글은 없습니다.");
       }
   }
   
   private void SearchBySBoardNum() {
	   System.out.println("조회하실 게시판 번호를 적어주세요.");
       System.out.print(">>>");
       int inputNumber = AppUI.InputInteger();
      
       boolean flag = true;
       for (int i = 0; i < DummyDatas.tUSs.size(); i++) {
           if(DummyDatas.tUSs.get(i).getSuggestNum() == inputNumber) {
               System.out.println(DummyDatas.tUSs.get(i));
               flag = false;
           }
       }   
       
       if(flag) {
    	   System.out.println("적어주신 게시판 번호로 조회되는 게시글은 없습니다.");
       }
   }
   
   private void WritingSuggestion() {
	   //회원번호를 받아주세요
       //작성글을 받아주세요
       //add

       System.out.println("회원번호를 입력해주세요");
       System.out.print(">>>");
       int inputNumber = AppUI.InputInteger();
      
       System.out.println("작성글을 입력해주세요");
       System.out.print(">>>");
       String inputWord = AppUI.InputString();
       
       System.out.println("입력이 완료되었습니다.");
       DummyDatas.tUSs.add(new TrainSuggestion(DummyDatas.tUSs.size()+1, DummyDatas.tUsers.get(inputNumber-1), inputWord));      
   }
}

package com.space.service;

import com.space.data.DummyDatas;
import com.space.global.AppUI;
import com.space.global.GlobalVariables;
import com.space.global.Start;

/*
 * Author: 최용준
 * ClassName : TrainUserCancellation
 * Funcs : Cancel the Reservation
 * Date: 2024-08-09
 * */
public class TrainUserCancellation implements Start{

	@Override
	public void start() {
		while(true){		
			AppUI.SeatsCancelationScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case 1: 
					TrainSeatsCancel();             //1. 예매 취소하기
					break;
				case GlobalVariables.returnNum:     //메인화면으로 돌아가기	
					return; 
				case GlobalVariables.terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;	
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}	
		
	}

	private void TrainSeatsCancel() {
		System.out.println("아이디를 입력해주세요");
		System.out.print(">>>");	
		int inputIdNum = AppUI.InputInteger();
		boolean flag = false;
		
		//case1. 예약이 안되어 있는 경우
		for(int i=0; i<DummyDatas.seats.size(); i++) {
			if(DummyDatas.seats.get(i).getTrainUser().getUserNum() == inputIdNum) {
				System.out.println("현재 예약하신 정보는 다음과 같습니다. ");
				System.out.println("#회원번호: " + DummyDatas.seats.get(i).getTrainUser().getUserNum());
				System.out.println("#회원이름: " + DummyDatas.seats.get(i).getTrainUser().getUserName());
				System.out.println("#열차정보: " + DummyDatas.seats.get(i).getTrain().getTrainName());
				System.out.println("#좌석정보: " + DummyDatas.seats.get(i).getSeatNum() + "번");
				flag = !flag;
			} 
		}
		
		if(!flag) {
			System.out.println("죄송합니다. 예약한 정보가 존재하지 않습니다. 이전화면으로 돌아갑니다.");
			return;			
		}
		
		System.out.println("정말 취소하시겠습니까? 취소하시려면 '예약취소'를 입력주세요");	
		System.out.println("(다른 글을 입력하면 예약이 취소됩니다!)");
		System.out.print(">>>");
		String inputText= AppUI.InputString();
		if(inputText.equals("예약취소")) {
			for(int i=0; i<DummyDatas.seats.size(); i++) {
				if(DummyDatas.seats.get(i).getTrainUser().getUserNum() == inputIdNum) {
					DummyDatas.seats.remove(i);
					System.out.println("예약이 취소되었습니다.");
				} 
			}			
		} else {
			System.out.println("이전 화면으로 돌아갑니다.");
		}	
	}
}

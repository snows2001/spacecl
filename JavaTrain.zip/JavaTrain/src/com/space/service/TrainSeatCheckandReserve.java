package com.space.service;

import com.space.data.DummyDatas;
import com.space.global.*;
import com.space.train.TrainSeats;

/*
 * Author: 최용준
 * ClassName : TrainSeatCheckandReserve
 * Funcs : TrainSeatCheck and SeatReservation
 * Date: 2024-08-09
 * */
public class TrainSeatCheckandReserve implements Start{

	@Override
	public void start() {
		while(true){
			AppUI.TrainSeatsChkNRsvScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case GlobalVariables.returnNum:     //상위 메뉴로 돌아가기
					return; 		
				case GlobalVariables.infoNum:       //좌석 확인하기
					TrainSeatsCheck();
					break;
				case GlobalVariables.reserveNum:    //좌석 예매하기
					TrainSeatsReserve();
					break;
				case GlobalVariables.terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}				
	}
	
	// 3-1. 예매한 좌석 확인하기 
	private void TrainSeatsCheck() {
		while(true){
			AppUI.SeatsCheckScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case GlobalVariables.returnNum:     //상위 메뉴로 돌아가기
					return; 	
				case GlobalVariables.findById:      //ID로 예매좌석 확인하기
					TrainSeatCheckByID();
					break;
				case GlobalVariables.findByName:    //이름으로 예매좌석 확인하기
					TrainSeatCheckByName();
					break;
				case GlobalVariables.terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}			
	}

	private void TrainSeatCheckByID() {
		System.out.println("아이디를 입력해주세요");
		System.out.print(">>>");	
		int inputIdNum = AppUI.InputInteger();
		
		boolean flag = true;
		for(int i=0; i<DummyDatas.seats.size(); i++) {
			if(DummyDatas.seats.get(i).getTrainUser().getUserNum() == inputIdNum) {
				System.out.println("예매하신 열차의 좌석정보는 다음과 같습니다.");
				System.out.println("#회원번호: " + DummyDatas.seats.get(i).getTrainUser().getUserNum());
				System.out.println("#회원이름: " + DummyDatas.seats.get(i).getTrainUser().getUserName());
				System.out.println("#열차정보: " + DummyDatas.seats.get(i).getTrain().getTrainName());
				System.out.println("#좌석정보: " + DummyDatas.seats.get(i).getSeatNum() + "번");
				flag = !flag;
			}
		}
		
//		for(int i = 0; i<DummyDatas.seats.size(); i++) {
//			System.out.println(DummyDatas.seats.get(i).toString());
//		}
//		System.out.println(DummyDatas.seats.size());
		
		if(flag == true) {
			System.out.println("해당 ID로 예매하신 정보는 존재하지 않습니다.");				
		}
	}
	
	private void TrainSeatCheckByName() {
		System.out.println("이름을 입력해주세요");
		System.out.print(">>>");	
		String inputName = AppUI.InputString();
		
		boolean flag = true;
		for(int i=0; i<DummyDatas.seats.size(); i++) {
			if(DummyDatas.seats.get(i).getTrainUser().getUserName().equals(inputName)) {
				System.out.println("예매하신 열차의 좌석정보는 다음과 같습니다.");
				System.out.println("#회원번호: " + DummyDatas.seats.get(i).getTrainUser().getUserNum());
				System.out.println("#회원이름: " + DummyDatas.seats.get(i).getTrainUser().getUserName());
				System.out.println("#열차정보: " + DummyDatas.seats.get(i).getTrain().getTrainName());
				System.out.println("#좌석정보: " + DummyDatas.seats.get(i).getSeatNum() + "번");
				flag = !flag;
			}
		}
		
		if(flag == false) {
			System.out.println("해당 이름으로 예매하신 정보는 존재하지 않습니다.");				
		}
	}

	// 3-2. 좌석 예매하기 
	private void TrainSeatsReserve() {
		System.out.println("예매를 시작합니다.");
		while(true){
			AppUI.SeatsReservationScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case GlobalVariables.rsvId:      //ID로 예매하기
					TrainReserveByID();
					break;
				case GlobalVariables.returnNum:  //상위 메뉴로 돌아가기
					return; 	
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}	
	}

	private void TrainReserveByID() {
		
		boolean canRsv = true;
		System.out.println("아이디를 입력해주세요");
		System.out.print(">>>");	
		int inputIdNum = AppUI.InputInteger();
		String rsvUser = DummyDatas.tUsers.get(inputIdNum).getUserName();
		
		//case1. 예약이 되어있는 경우 = 예약불가 + 함수탈출
		for(int i=0; i<DummyDatas.seats.size(); i++) {
			if(DummyDatas.seats.get(i).getTrainUser().getUserNum() == inputIdNum) {
				System.out.println("죄송합니다 "+rsvUser+"님. 좌석은 한 사람당 1장만 예약이 가능합니다.");
				canRsv = !canRsv;
				return;
			}
		}
				
		//case1.예약이 되어있지 않은 경우	
		System.out.println("반간습니다. "+rsvUser+"님!");			
		System.out.println("예매하실 열차 번호를 입력해주세요.");		
		System.out.println("[2.새마을호 / 4.무궁화호 / 6.ITX  / 8.KTX]");		
		System.out.print(">>>");
		int inputTrainNum = AppUI.InputInteger();
		switch(inputTrainNum) {
			case GlobalVariables.saemaeulCode:  //새마을호
			case GlobalVariables.mugunghwaCode: //무궁화호
			case GlobalVariables.itxCode:       //ITX
			case GlobalVariables.ktxCode:       //KTX	
				break;
			default:	
				System.out.println("잘못된 열차번호를 입력하여 이전메뉴로 돌아갑니다.");
				return; //메인화면으로 돌아가기			
		}	
		
		System.out.println("예매하실 좌석 번호를 입력해주세요.");	
		System.out.print(">>>");
		int inputSeatNum = AppUI.InputInteger();
		//case 2-1. 예약하고자 하는 자리가 예약 되어 있는 경우 <-다른 메소드로 분리
		for(int i = 0; i<DummyDatas.seats.size(); i++) {
			if(DummyDatas.seats.get(i).getTrain().getTrainNo() == inputTrainNum &&
			   DummyDatas.seats.get(i).getSeatNum() == inputSeatNum) {
				System.out.println("자리가 이미 예약되어있습니다. 이전 화면으로 돌아갑니다.");		
				canRsv = !canRsv;
				return;
			}
		}
		
		//case 2-2. 예약하기
		if(canRsv) {		
			for(int i=0; i<DummyDatas.trains.size(); i++) {
				if(DummyDatas.trains.get(i).getTrainNo() == inputTrainNum) {
					DummyDatas.seats.add(new TrainSeats(
							DummyDatas.tUsers.get(inputIdNum), 
							DummyDatas.trains.get(i), 
							inputSeatNum));					
				}
			}
			
			System.out.println(DummyDatas.tUsers.get(inputIdNum).getUserName() + "님의 예약 정보입니다.");	
			System.out.println(DummyDatas.seats.get(DummyDatas.seats.size()-1).toString());
		} else {
			System.out.println("모종의 이유로 예약이 취소되었습니다. 이전 화면으로 돌아갑니다.");
			return;
		}	
		
//		for( int i=0; i<DummyDatas.seats.size(); i++) {
//			System.out.println(DummyDatas.seats.get(i).toString());
//		}
	}
}

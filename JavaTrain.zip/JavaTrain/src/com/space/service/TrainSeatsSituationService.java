package com.space.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.space.data.DummyDatas;
import com.space.global.*;

/*
 * Author: 최용준
 * ClassName : TrainSeatsSituationService
 * Funcs : Show TrainSeatsSituation
 * Date: 2024-08-06
 * */
public class TrainSeatsSituationService implements Start{

	private String departure, arrival, duration;
	private LocalDateTime departTime, arriveTime;
	@Override
	public void start() {
		while(true){
			AppUI.TrainSeatsSituationScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case GlobalVariables.returnNum:     //상위 메뉴로 돌아가기
					return; //메인화면으로 돌아가기			
				case GlobalVariables.searchAll:     //전체검색
					ShowAllReservedSeats();
					break;
				case GlobalVariables.saemaeulCode:  //새마을호
				case GlobalVariables.mugunghwaCode: //무궁화호
				case GlobalVariables.itxCode:       //ITX
				case GlobalVariables.ktxCode:       //KTX
					SelectTrainReservedSeat(selection);
					break;
				case GlobalVariables.terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}						
	}

	private void ShowAllReservedSeats() {
		SelectTrainReservedSeat(GlobalVariables.saemaeulCode);
		System.out.println();
		SelectTrainReservedSeat(GlobalVariables.mugunghwaCode);
		System.out.println();
		SelectTrainReservedSeat(GlobalVariables.itxCode);
		System.out.println();
		SelectTrainReservedSeat(GlobalVariables.ktxCode);		
	}
	
	private void SelectTrainReservedSeat(int selection) {
		switch(selection) {
			case GlobalVariables.saemaeulCode:  //새마을호
				System.out.println("새마을호의 예약되어있는 좌석은 다음과 같습니다.");
				break;	
				
			case GlobalVariables.mugunghwaCode: //무궁화호			
				System.out.println("무궁화호의 예약되어있는 좌석은 다음과 같습니다.");
				break;	
				
			case GlobalVariables.itxCode:       //ITX
				System.out.println("ITX의 예약되어있는 좌석은 다음과 같습니다.");
				break;	
				
			case GlobalVariables.ktxCode:       //KTX
				System.out.println("KTX의 예약되어있는 좌석은 다음과 같습니다.");
				break;		
		}
		
		System.out.println("[예약가능한 자리: ○ / 예약되어있는 자리: ●]");
		String[] seatsSituation = new String[8];

		for(int i=0; i<seatsSituation.length; i++) {		
			seatsSituation[i]="○";
		}	
		for(int i=0; i<DummyDatas.seats.size(); i++) {
			if( DummyDatas.seats.get(i).getTrain().getTrainNo() == selection) {
				seatsSituation[DummyDatas.seats.get(i).getSeatNum()-1] = "●";	
				departure = DummyDatas.seats.get(i).getTrain().getDeparture();
				departTime = DummyDatas.seats.get(i).getTrain().getTrainETD();
				arrival = DummyDatas.seats.get(i).getTrain().getArrival();
				arriveTime = DummyDatas.seats.get(i).getTrain().getTrainETA();	
				duration = AppUI.BlockTime(departTime, arriveTime);
			}			
		}
		System.out.print("[도착지: " + arrival +"] <-진행방향 H<");		
		for(int j=0; j<seatsSituation.length; j++) {		
			System.out.print(seatsSituation[j]);
		}					
		System.out.println(">T [출발지: " + departure + "]");
		
		System.out.println("[도착예정시간: " + arriveTime.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분")) + "]/[출발예정시간: "
				+ departTime.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분")) + "]" );
		System.out.println(duration);                                                                                                                                                                                                                                                                                                                     
	}
}

package com.space.service;

import com.space.global.AppUI;
import com.space.global.GlobalVariables;
import com.space.global.Start;

public class TrainUserReservation implements Start{

	@Override
	public void start() {
		while(true){
			AppUI.TrainSeatsChkNRsvScreen();
			int selection = AppUI.InputInteger();
			
			switch(selection) {
				case GlobalVariables.returnNum:     //상위 메뉴로 돌아가기
					return; //메인화면으로 돌아가기			
				case GlobalVariables.infoNum:       //좌석 확인하기
					
					break;
				case GlobalVariables.reserveNum:  //좌석 예매하기

					break;
				case GlobalVariables.terminateNum:  //프로그램 종료
					AppUI.Shutdown();
					break;
				default:
					AppUI.DefaultMessages();		
			}
			AppUI.PressEnter();
			AppUI.InputString();
		}		
		
		
	}
	
	

}

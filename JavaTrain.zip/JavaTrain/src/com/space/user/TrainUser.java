package com.space.user;

/*
 * Author: 최용준
 * ClassName : TrainUser
 * Funcs : User Class
 * Date: 2024-07-30
 * */
public class TrainUser {
	
	private int userNum;         	//유저번호
	private String userName;     	//유저 이름
	private int budget;          	//유저 자산   

	
	public TrainUser() {} //default Csrt
	
	public TrainUser(int userNum, String userName, int budget) {
		super();
		this.userNum = userNum;
		this.userName = userName;
	}
	
	public int getUserNum() {
		return userNum;
	}

	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getBudget() {
		return budget;
	}

	public void setBudget(int budget) {
		this.budget = budget;
	}

	@Override
	public String toString() {
		System.out.println("조회하신 유저정보는 다음과 같습니다.");
		return "[회원번호: " + userNum + 
			   ", 회원이름: " + userName + 
			   ", 회원자산: " + budget + "]";
	}	
	
}

package com.space.main;

import com.space.data.DummyDatas;
import com.space.global.AppUI;

/*
 * Author: 최용준
 * ClassName : TrainMain
 * Funcs : TrainRsv MainClass
 * Date: 2024-07-30
 * */
public class TrainMain {

	public static void main(String[] args) {	
		DummyDatas.InitializeData();
		AppController controller = new AppController();
		
		while(true) {
			AppUI.startScreen(); 
			int inputNumber = AppUI.InputInteger();
			controller.chooseSystem(inputNumber);
		}
	}
}

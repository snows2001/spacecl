package com.space.main;

import com.space.global.*;
import com.space.service.*;

/*
 * Author: 최용준
 * ClassName : AppController
 * Funcs : Controller
 * Date: 2024-07-30
 * */
public class AppController {
	
	TrainInfomationService tInfo = new TrainInfomationService();
	TrainSeatsSituationService tSituation = new TrainSeatsSituationService();
	TrainSeatCheckandReserve tChkNRsv = new TrainSeatCheckandReserve();
	TrainUserCancellation tCancel = new TrainUserCancellation();
	TrainSuggestionService tSuggest = new TrainSuggestionService();
	
	public void chooseSystem(int inputNum) {		
		switch(inputNum) {  	
	    	//현재 열차의 운행정보
	    	case GlobalVariables.infoNum: 
	    		System.out.println("열차정보 모드로 돌입합니다.");
	    		tInfo.start();
	    		break;
	    		
	    	//예매되어있는 좌석정보확인 	
	    	case GlobalVariables.situationNum:     
	    		System.out.println("예매되어있는 좌석정보확인모드로 돌입합니다."); 
	    		tSituation.start();
	    		break;
	    		
	    	//예매한 좌석확인 및 좌석예매 	
	    	case GlobalVariables.chkNRsvNum:     
	    		System.out.println("예매한 좌석확인 및 좌석예매모드로 돌입합니다."); 
	    		tChkNRsv.start();
	    		break;
	    		
	    	//예매좌석 취소
	    	case GlobalVariables.cancelNum:
	    		System.out.println("예약 취소 모드로 돌입합니다.");
	    		tCancel.start();
	    		break;
	    		
	    	//고객제안 	
	    	case GlobalVariables.suggestNum:
	    		System.out.println("고객 제안 모드로 돌입합니다.");
	    		tSuggest.start();
	    		break;
	    	
	    	//프로그램 종료
	    	case GlobalVariables.terminateNum:
	    		AppUI.Shutdown();
	    		break;
	    		
	    	default:
	    		AppUI.DefaultMessages();
	    		break;
		}
	}
}

    
   


package com.space.train;

import com.space.user.TrainUser;

public class TrainSeats {
	
	private TrainUser trainUser;      //유저
	private Train train;   //열차
	private int seatNum;              //좌석번호 
	
	public TrainSeats(TrainUser trainUser, Train train, int seatNum) {
		super();
		this.trainUser = trainUser;
		this.train = train;
		this.seatNum = seatNum;
	}

	public TrainUser getTrainUser() {
		return trainUser;
	}

	public void setTrainUser(TrainUser trainUser) {
		this.trainUser = trainUser;
	}

	public Train getTrain() {
		return train;
	}

	public void setTrain(Train train) {
		this.train = train;
	}

	public int getSeatNum() {
		return seatNum;
	}

	public void setSeatNum(int seatNum) {
		this.seatNum = seatNum;
	}

	@Override
	public String toString() {
		return "좌석정보 [예약자:" + trainUser.getUserName() + ", 예약한 열차이름:" + train.getTrainName() + ", 좌석번호: " + seatNum + "]";
	}
}

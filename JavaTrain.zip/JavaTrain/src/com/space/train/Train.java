package com.space.train;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/*
 * Author: 최용준
 * ClassName : Train
 * Funcs : Train Class
 * Date: 2024-07-30
 * */
public class Train {
    
	private int trainNo;           		    //열차번호 
	private String trainName;               //열차 이름
	private String departure;				//출발지 이름
    private LocalDateTime trainETD;   	    //Estimated Time of Departure(출발예정시간)
    private String arrival;				 	//도착지 이름
    private LocalDateTime trainETA;  	    //Estimated Time of Arrival(도착예정시간)

    public Train(int trainNo, String trainName, String departure, LocalDateTime trainETD, 
    		String arrival, LocalDateTime trainETA) {
    	super();
    	this.trainNo = trainNo;
    	this.trainName = trainName;
    	this.departure = departure;
    	this.trainETD = trainETD;
    	this.arrival = arrival;
    	this.trainETA = trainETA;
    }
    
	public int getTrainNo() {
		return trainNo;
	}

	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public LocalDateTime getTrainETD() {
		return trainETD;
	}

	public void setTrainETD(LocalDateTime trainETD) {
		this.trainETD = trainETD;
	}

	public String getArrival() {
		return arrival;
	}

	public void setArrival(String arrival) {
		this.arrival = arrival;
	}

	public LocalDateTime getTrainETA() {
		return trainETA;
	}

	public void setTrainETA(LocalDateTime trainETA) {
		this.trainETA = trainETA;
	}
	
	@Override
    public String toString() {
		return "[열차이름: " + trainName + " / 출발지: " + departure + " / 예정출발시간: "+ trainETD.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분"))+ "]\n[열차번호: " + trainNo + " / 도착지: " + arrival + " / 예정도착시간: " + trainETA.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분")) + "]\n"+
		"------------------------------------------";
    }

}
